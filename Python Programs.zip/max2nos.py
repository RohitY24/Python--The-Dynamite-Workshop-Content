a=int(input("First no: "))
b=int(input("Second number: "))
print(max(a,b))