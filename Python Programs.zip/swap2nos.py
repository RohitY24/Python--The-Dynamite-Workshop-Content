#swap without assignment operators
a=int(input("First:  "))
b=int(input("Second:  "))
a,b=b,a
print(a,b)