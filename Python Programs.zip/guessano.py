myno=100
while 1:
    n=int(input("Guess the number:"))
    if n==myno:
        print("You guessed the number!")
        break
    else:
        print("Wrong guess")

print("Game Over")